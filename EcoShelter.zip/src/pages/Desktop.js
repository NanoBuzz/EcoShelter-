import styles from "./Desktop.module.css";

const Desktop = () => {
  return (
    <div className={styles.desktop}>
      <div className={styles.frameParent}>
        <div className={styles.aboutParent}>
          <h1 className={styles.about}>About</h1>
          <div className={styles.ourPlatformAimsToSuggestLWrapper}>
            <b className={styles.ourPlatformAims}>
              Our platform aims to suggest low carbon construction materials
              according to the climatic conditions of the user’s given location.
              It intents to create a eco-friendly environment by reducing carbon
              emissions and an individual’s carbon footprints. This also helps
              to reduce the greenhouse effect. Our primary goal is to create a
              low carbon economy.
            </b>
          </div>
        </div>
        <div className={styles.contactParent}>
          <h1 className={styles.contact}>Contact</h1>
          <div className={styles.no1EcoStreetChennai60Wrapper}>
            <b className={styles.no1EcoStreetContainer}>
              <p className={styles.p}>☎️ : 987654321</p>
              <p className={styles.p1}>{`📧 : `}</p>
              <p className={styles.no1EcoStreet}>
                📍 : No-1, Eco street, Chennai - 600000
              </p>
            </b>
          </div>
        </div>
      </div>
      <div className={styles.desktopInner}>
        <div className={styles.screenshot202403232157291Parent}>
          <img
            className={styles.screenshot202403232157291}
            loading="lazy"
            alt=""
            src="/screenshot-20240323-215729-1@2x.png"
          />
          <img
            className={styles.screenshot202403211434241}
            loading="lazy"
            alt=""
            src="/screenshot-20240321-143424-1@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

export default Desktop;
